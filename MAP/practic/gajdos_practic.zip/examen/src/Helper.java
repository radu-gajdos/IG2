public class Helper {
    public boolean isLower(char c)
    {

        return c >= 'a' && c <= 'z';
    }
}
