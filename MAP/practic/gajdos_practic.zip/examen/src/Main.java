import java.io.IOException;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) throws IOException, InterruptedException {
        AnimalManager animalManager = new AnimalManager(new ArrayList<>());
        animalManager.addAnimalsFromFile("C:\\Users\\Radu\\Desktop\\s2_zoo\\examen\\animals_inventory.csv");
        System.out.println(animalManager);

        animalManager.WriteSpecificToFile();


        //Proxy Pattern
        //folosesc proxy ca sa nu utilizez caretake-erul actual pentru a apela functia steal, ci un proxy
        AnimalCareTacker animalCareTacker = new AnimalCareTacker("alexandruuu", 12);
        AnimalCareTakerProxy animalCareTakerProxy = new AnimalCareTakerProxy(animalCareTacker);
        animalCareTakerProxy.steal();

        Doctor doctor = new Doctor();
        Virus virus = new Virus();
        Animal animal = new Animal("animal", "animal", "15", "Cage", "Sick");
        doctor.setAnimal(animal);
        virus.setAnimal(animal);
        while (true) {
            doctor.run();
            virus.run();
        }
    }
}